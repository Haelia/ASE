AGEZ Adrien & WISSOCQ Sarah

make -> Compile switch_to
