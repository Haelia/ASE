Sarah Wissocq
Adrien Agez


make -> Compile try_mul et display_stack


